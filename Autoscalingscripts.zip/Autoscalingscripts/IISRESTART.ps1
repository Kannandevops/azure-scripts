#         Script Name : iisrestart.ps1
#
#  Scripting Language : PowerShell
#
#                Date : 9th May 2015
#
#             Purpose : Restart IIS until all the services are stopped
#
#             Author  : JDA
#
#             

#Setting up variables
$BASE_DIR="C:\LOGS\AppLogs"
$host_name=hostname
$LOG_FILE=$BASE_DIR + "\" +$host_name + "_iisreset_Logpostserverbuild.log"
echo $LOG_FILE
$no_of_try=0

write-output "$(get-date) : Stopping IIS " | out-file $LOG_FILE -Append -Force;  

#Stopping IIS
iisreset /stop

write-output "$(get-date) : Checking Status of IIS" $(iisreset /status) | out-file $LOG_FILE -Append -Force;  
sleep 10

#Starting IIS, looping until all Services are started
do
{
  # If the no of retries exceed 3, breaking the loop
  if ( $no_of_try -gt 3 )
  {
    write-output "$(get-date) : Exiting after 4 tries  " | out-file $LOG_FILE -Append -Force; 
    break
  }

  #Checking status of IIS and if it is completely stopped starting it
  if ( ( iisreset /status | Select-String "Stopped" ) -or ( iisreset /status | Select-String "Starting" ) )
  {
    write-output "$(get-date) : Starting IIS " | out-file $LOG_FILE -Append -Force;   
    iisreset /restart
  }
sleep 15
$no_of_try++

}until ( ! ( iisreset /status | Select-String "Stopped" ) -and ! ( iisreset /status | Select-String "Starting" ) )

write-output "$(get-date) : Checking Status of IIS"  $(iisreset /status) | out-file $LOG_FILE -Append -Force;  
write-output "*************************************************************" | out-file $LOG_FILE -Append -Force;
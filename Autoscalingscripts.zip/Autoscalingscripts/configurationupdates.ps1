﻿#=================================================================================================================================================================
# This script will update the configurations for ESO-WFMR
#=================================================================================================================================================================

$gs_web_template = '\\jda-hmm\c$\templates\WebGlobalsettings_template.xml'
$logcfg_template = '\\jda-hmm\c$\templates\logconfig_template.xml'
$rpweb_template =  '\\jda-hmm\c$\templates\rpweb_template.xml'
$gs_new = 'C:\EPS\Globalsettings.xml'
$rpweb_new= 'C:\RedPrairieRetail\DefaultInstance\Personae\Tomcat\WEB-INF\settings\rpweb.xml'
$logcfg_new = 'C:\EPS\logconfig.xml'
$Servername=$env:COMPUTERNAME
$base_file_name='C:\log\' + $env:COMPUTERNAME
$log_loc='C:\LOGS\ConfigurationLogs'

         (Get-Content $gs_web_template) | Foreach-Object {
         $_ -replace 'localhostfqdn', $servername
        } | Set-Content $gs_new
        if($?) { Write-Output "$(get-date) : globalsetting has been prepared for $env:computername. Please validate " >> $log_loc }
        else { Write-Output "$(get-date) : globalsetting could not be prepared for $env:computername. Please check the script config " >> $log_loc }     

         (Get-Content $logcfg_template) | Foreach-Object {
         $_ -replace 'path', $base_file_name
        } | Set-Content $logcfg_new
         if($?) { Write-Output "$(get-date) : logconfig has been prepared for $env:computername. Please validate " >> $log_loc }
        else { Write-Output "$(get-date) : logconfig could not be prepared for $env:computername. Please check the script config " >> $log_loc } 

        #Persona Configurations 

        (Get-Content $rpweb_template) | Foreach-Object { 
        $_ -replace 'node', $servername
        } | Set-Content $rpweb_new   
          if($?) { Write-Output "$(get-date) : RPWEB has been prepared for $env:computername. Please validate " >> $log_loc }
        else { Write-Output "$(get-date) : RPWEB could not be prepared for $env:computername. Please check the script config " >> $log_loc }

      #creating task schedulers 

$Trigger= New-ScheduledTaskTrigger -At 10:00am -Daily
$User= "NT AUTHORITY\SYSTEM"
$Action= New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "C:\admin\scripts\tomcatrestart.ps1"
if ((Register-ScheduledTask -TaskName "tomcatrestart" -Trigger $Trigger -User $User -Action $Action -RunLevel Highest –Force).state -eq 'Ready')
{write-output "$(get-date) : Tomcat restart has been created sucessfullly" >> $log_loc} 
else  {write-output "$(get-date) : Tomcat restart has not been created sucessfullly" >> $log_loc} 

       

$Trigger= New-ScheduledTaskTrigger -At 10:00am -Daily
$User= "NT AUTHORITY\SYSTEM"
$Action= New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "C:\admin\scripts\iisrestart.ps1"
if ((Register-ScheduledTask -TaskName "iisrestart" -Trigger $Trigger -User $User -Action $Action -RunLevel Highest –Force).state -eq 'Ready')
{write-output "$(get-date) : IISrestart has been created sucessfullly" >> $log_loc} 
else  {write-output "$(get-date) : IISrestart has not been created sucessfullly" >> $log_loc} 


















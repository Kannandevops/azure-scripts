﻿############################Setting up the ACL Permissions for the folder#################################

$sharepath = "\\$env:computername\c$\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1"
$Acl = Get-ACL $SharePath
$AccessRule= New-Object System.Security.AccessControl.FileSystemAccessRule("everyone","FullControl","ContainerInherit,Objectinherit","none","Allow")
$Acl.AddAccessRule($AccessRule)
Set-Acl $SharePath $Acl


$sharepath = "\\$env:computername\c$\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1"
$Acl = Get-ACL $SharePath
$AccessRule= New-Object System.Security.AccessControl.FileSystemAccessRule("kannan","FullControl","ContainerInherit,Objectinherit","none","Allow")
$Acl.AddAccessRule($AccessRule)
Set-Acl $SharePath $Acl


$sharepath = "\\$env:computername\c$\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1"
$Acl = Get-ACL $SharePath
$AccessRule= New-Object System.Security.AccessControl.FileSystemAccessRule("Network Service","FullControl","ContainerInherit,Objectinherit","none","Allow")
$Acl.AddAccessRule($AccessRule)
Set-Acl $SharePath $Acl

############################Copying the files from the Source Folder#################################

Move-Item -Path "C:\RedPrairieRetail\DefaultInstance\Personae\Tomcat\WEB-INF\settings\rpweb.xml" -Destination "C:\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1"
Move-Item -Path "C:\EPS\globalsettings.xml" -Destination "C:\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1"
Move-Item -Path "C:\EPS\logconfig.xml" -Destination "C:\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1"
Move-Item -Path "C:\config\anonymousauthentication.bat" -Destination "C:\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1"
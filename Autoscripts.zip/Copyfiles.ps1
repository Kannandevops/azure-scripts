﻿$src_dir = "\\jdaautocf000000\c$\config"
$dst_dir = "C:\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1"
$file = Get-ChildItem $src_dir  
$LOG_FILE ="C:\LOGS\AppLogs"  + "\copystatus" +".log"
Copy-Item -path $file -Destination $dst_dir -Force -PassThru | Out-file $LOG_FILE -Append -Force
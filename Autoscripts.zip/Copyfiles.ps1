﻿$src_dir = "\\jdaautocf000000\c$\config\*"
$dst_dir = "C:\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1" 
$LOG_FILE ="C:\LOGS\AppLogs"  + "\copystatus" +".log"
Copy-Item -path $src_dir -Destination $dst_dir -Force -PassThru | Out-file $LOG_FILE -Append -Force
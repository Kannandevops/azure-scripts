﻿############################Copying the files from the Source Folder#################################

Copy-Item -Path "C:\Templates\rpweb_template.xml" -Destination "C:\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1"
Copy-Item -Path "C:\Templates\Globalsettings_web_template.xml" -Destination "C:\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1"
Copy-Item -Path "C:\Templates\logconfig_template" -Destination "C:\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1"

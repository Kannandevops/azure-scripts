﻿$source = "\\jdaautocf000000\c$\config"
$destination = "C:\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1"
$Date = get-date
$items = Get-ChildItem -Path $source -Recurse
foreach($item in $items)
{
	try
	{
		$copiedItems=Copy-Item "$source\$item" -Destination $destination -Force -Recurse -PassThru 
		"$([DateTime]::Now)" + "`t$source\$item`t is copied onto $destination"| out-file c:\copied.txt -Append
	}
	catch
	{
		"$source\$item"+": " + $_.Exception.message | Out-File c:\Notcopied.txt -Append
	}
}
﻿############################Setting up the ACL Permissions for the folder#################################

$sharepath = "\\$env:computername\c$\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1"
$Acl = Get-ACL $SharePath
$AccessRule= New-Object System.Security.AccessControl.FileSystemAccessRule("everyone","FullControl","ContainerInherit,Objectinherit","none","Allow")
$Acl.AddAccessRule($AccessRule)
Set-Acl $SharePath $Acl

############################Copying the files from the Source Folder#################################


$source = "\\jdaautocf000000\c$\config"
$items =  Get-ChildItem -Path $source -Recurse
$destination = "\\$env:computername\c$\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1"
$Date = get-date

foreach($item in $items)
{
	try
	{
		$copiedItems=Copy-Item "$source\$item" -Destination $destination -Force -Recurse -PassThru 
		"$([DateTime]::Now)" + "`t$source\$item`t is copied onto $destination"| out-file c:\copied.txt -Append
	}
	catch
	{
		"$source\$item"+": " + $_.Exception.message | Out-File c:\Notcopied.txt -Append
	}
}
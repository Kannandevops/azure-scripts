﻿


#Setting up variables
$BASE_DIR="C:\LOGS\AppLogs"
$host_name=hostname
$LOG_FILE=$BASE_DIR + "\" +$host_name + "_iisreset_Log.log"
$ServiceName = 'Tomcat8'
$tomcat_LOG=$BASE_DIR + "\" +$host_name + "_Tomcat_Log.log"
$arrService = Get-Service -Name $Servicename

#Stopping the IIS on the Server 
IISRESET /stop
write-output "$(get-date) :stopping the IIS on the server" $(IIsreset /status) | out-file $LOG_FILE -Append -Force; 
sleep 10

#checking the status of iis on the server  
if (iisreset /status | select-string "stopped")
#start the IIS on the server
{iisreset /start 
write-output "$(get-date) :Starting the iisreset on the server" | out-file $LOG_FILE -Append -Force; }
sleep 15
if (iisreset /status | select-string "running")
{write-output "$(get-date) :Starting the iisreset on the server" $(IIsreset /status) | out-file $LOG_FILE -Append -Force;
 }



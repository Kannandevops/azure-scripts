﻿$BASE_DIR="C:\LOGS\AppLogs"
$host_name=hostname
$ServiceName = 'Tomcat8'
$tomcat_LOG=$BASE_DIR + "\" +$host_name + "_Tomcat_Log.log"
#$arrService = Get-Service -name $ServiceName
 
  Stop-Service $ServiceName
  write-output "$(get-date) : Stopping the tomcat service" ((Get-Service -name $ServiceName).status )  | out-file $tomcat_LOG -Append -Force;  
  sleep 40

  if ((Get-Service -name $ServiceName).status -eq 'stopped') 
 {start-service $ServiceName  
 
 write-output "$(get-date) : Starting the tomcat service" (Get-Service -name $ServiceName).status| out-file $tomcat_LOG -Append -Force
 sleep 40}

 if ( (Get-Service -name $ServiceName).status -eq 'Running')
 { write-output "$(get-date) : Tomcat Services are " (Get-Service -name $ServiceName).status | out-file $tomcat_LOG -Append -Force};


﻿#=================================================================================================================================================================
# This script will update the configurations for ESO-WFMR
#=================================================================================================================================================================

$gs_web_template = 'C:\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1\WebGlobalsettings_template.xml'
$logcfg_template = 'C:\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1\logconfig_template.xml'
$rpweb_template =  'C:\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1\rpweb_template.xml'
$gs_new = 'C:\EPS\Globalsettings.xml'
$rpweb_new= 'C:\RedPrairieRetail\DefaultInstance\Personae\Tomcat\WEB-INF\settings\rpweb.xml'
$logcfg_new = 'C:\EPS\logconfig.xml'
$Servername=hostname
$base_file_name='C:\log\' + $Servername
$log_loc='C:\LOGS\ConfigurationLogs'
$mywebserver='$env:computername'
$farmName = "Tomcat Redirector"
$fqdn = $mywebserver
$PSPath = 'MACHINE/WEBROOT/APPHOST'

######################################################
# Update the Anonymous Authentication Credentials
######################################################



cd C:\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1\WebGlobalsettings_template.xml
cmd.exe /c 'Anonymousauthentication.bat'

###################################################################
# Update the Configuration settings for RPWEB and Global Settings
###################################################################


         (Get-Content $gs_web_template) | Foreach-Object {
         $_ -replace 'localhostfqdn', $servername
        } | Set-Content $gs_new
        if($?) { Write-Output "$(get-date) : globalsetting has been prepared for $servername. Please validate " >> $log_loc }
        else { Write-Output "$(get-date) : globalsetting could not be prepared for $servername. Please check the script config " >> $log_loc }     

         (Get-Content $logcfg_template) | Foreach-Object {
         $_ -replace 'path', $base_file_name
        } | Set-Content $logcfg_new
         if($?) { Write-Output "$(get-date) : logconfig has been prepared for $servername. Please validate " >> $log_loc }
        else { Write-Output "$(get-date) : logconfig could not be prepared for $servername. Please check the script config " >> $log_loc } 

        #Persona Configurations 

        (Get-Content $rpweb_template) | Foreach-Object { 
        $_ -replace 'node', $servername
        } | Set-Content $rpweb_new   
          if($?) { Write-Output "$(get-date) : RPWEB has been prepared for $servername. Please validate " >> $log_loc }
        else { Write-Output "$(get-date) : RPWEB could not be prepared for $servername. Please check the script config " >> $log_loc }


#############################################################################
# Update the Farm Settings for  Tomcat Redirector 
###################################################################



#####################
# Remove Old
#####################
remove-WebConfigurationProperty -pspath $PSPath  -filter "webFarms/webFarm[@name='$farmName']" -name "."


###################
#  Add New
##################
Add-WebConfigurationProperty -pspath $PSPath  -filter "webFarms/webFarm[@name='$farmName']" -name "." -value @{address=$fqdn}

Set-WebConfigurationProperty -pspath $PSPath `
    -Filter "webFarms/webFarm[@name='$farmName']/server[@address='$fqdn']" `
    -Name 'applicationRequestRouting' `
    -Value @{ httpPort = 8080 }


 ###########################
Creating the Task Schedulers
############################

$Trigger= New-ScheduledTaskTrigger -At 10:00am -Daily
$User= "NT AUTHORITY\SYSTEM"
$Action= New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "C:\admin\scripts\tomcatrestart.ps1"
if ((Register-ScheduledTask -TaskName "tomcatrestart" -Trigger $Trigger -User $User -Action $Action -RunLevel Highest –Force).state -eq 'Ready')
{write-output "$(get-date) : Tomcat restart has been created sucessfullly" >> $log_loc} 
else  {write-output "$(get-date) : Tomcat restart has not been created sucessfullly" >> $log_loc} 

       

$Trigger= New-ScheduledTaskTrigger -At 10:00am -Daily
$User= "NT AUTHORITY\SYSTEM"
$Action= New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "C:\admin\scripts\iisrestart.ps1"
if ((Register-ScheduledTask -TaskName "iisrestart" -Trigger $Trigger -User $User -Action $Action -RunLevel Highest –Force).state -eq 'Ready')
{write-output "$(get-date) : IISrestart has been created sucessfullly" >> $log_loc} 
else  {write-output "$(get-date) : IISrestart has not been created sucessfullly" >> $log_loc} 


















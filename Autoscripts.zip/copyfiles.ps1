﻿$Localfiles = "\\jdaautocf000000\c$\config\*"
$Remotefiles = "\\$env:computername\C$\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9.5\Downloads\1\"
$LOG_FILE ="C:\LOGS\AppLogs"  + "\copystatus" +".log"
copy-item -path $Localfiles -Destination $Remotefiles -Recurse  -Force -PassThru | Out-file $LOG_FILE -Append -Force 

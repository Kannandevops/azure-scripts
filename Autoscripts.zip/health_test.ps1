
#         Script Name : health_test.ps1
#
#        Developed By : Vijay Saini
#  Scripting Language : PowerShell
#
#                Date : 2nd January 2017
#
#             Purpose : To perform the health test and get it documented
#
#             Author  : JDA
#
#      

############### Setting up the registry to add the website to Compatibilty list#######################

$key = "HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft"
if(-Not (Test-Path "$key\Internet Explorer")) {
New-Item -Path $key -Name "Internet Explorer" | Out-Null
}

if(-Not (Test-Path "$key\Internet Explorer\BrowserEmulation")) {
New-Item -Path "$key\Internet Explorer" -Name "BrowserEmulation" | Out-Null
}
 
if(-Not (Test-Path "$key\Internet Explorer\BrowserEmulation\PolicyList")) {
New-Item -Path "$key\Internet Explorer\BrowserEmulation" -Name "PolicyList" | Out-Null
}

$domain="azure.com"
$regkey = "$key\Internet Explorer\BrowserEmulation\PolicyList"

New-ItemProperty -Path $regkey -Name $domain -Value $domain -PropertyType String | Out-Null       
Remove-Variable * -ErrorAction SilentlyContinue
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12


#Configuration file name is coming from argument.(Full name of config file with extension)
#$config_file=$args[0]
$config_file='Server_App'

#Setting up variables
$BASE_DIR=(Resolve-Path .\).Path

$host_name=hostname
$ddMMyyyy=(Get-Date).ToString('dd-MM-yyyy');
$LOG_FILE=$BASE_DIR + "\OUTPUT\" +$config_file + "_health_test-"+$ddMMyyyy +".log"
$html_report=$BASE_DIR  +"\OUTPUT\"+$config_file + "_health_report_"+$ddMMyyyy +".html"
$html_file=$BASE_DIR  +"\OUTPUT\"+$config_file + "_health_data_"+$ddMMyyyy +".html"
$html_summary=$BASE_DIR  +"\OUTPUT\"+$config_file + "_summary_"+$ddMMyyyy +".html"
$persona_summary=$BASE_DIR  +"\OUTPUT\"+$config_file + "_persona_summary_"+$ddMMyyyy +".html"

$max_trial_allowed=4
$sleeptime =1
$nl = [Environment]::NewLine


$global_values=$BASE_DIR + "\configuration\GlobalSettings.ini"
$envt_details=$BASE_DIR + "\configuration\" + "$config_file.ini"


$public_url="";
$server_protocol="";

$app_servers_to_validate="";
$web_servers_to_validate="";
$web_services="";

$db_server='';
$db_name='';
$db_user='';
$db_pass='';

$output_into_single_file_enable="";
$validate_services="";
$health_test="";
$user_name="";
$user_password="";
$test_email="";


#Email Realted
$mail_from=''
$mail_to=''
$mail_cc=''
$success_mail_subject=''
$failure_mail_subject=''
$smtpserver=''
$envt_type=''
$email_flag='TRUE'
$persona_validation=''
$global:step_number=0;

. $BASE_DIR"\library\functions_library.ps1"

# Starting the script execution
write-output "===========================================================================" > $LOG_FILE;
write-output "$(get-date) : Staring the script " | out-file $LOG_FILE -Append -Force;  
write-output "Configuration file is:  $envt_details" | out-file $LOG_FILE -Append -Force;  


. $BASE_DIR"\library\read_config.ps1"

$app_servers_to_validate=$app_servers_to_validate -split ',';
$web_servers_to_validate=$web_servers_to_validate -split ',';
$web_services=$web_services -split ',';
$app_services=$app_services -split ',';


#-------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------
# Now we have all necessary values. We can go ahead with the health test


write-output "" | out-file $html_summary;
write-output "<br>" | out-file $html_summary -Append -Force;
write-output "<table border='2px' style='border-collapse: collapse;'>" | out-file $html_summary -Append -Force; 
write-output "<tr bgcolor='yellow'>" | out-file $html_summary -Append -Force; 
write-output "<td><b>Step Number</b></td>" | out-file $html_summary -Append -Force; 
write-output "<td><b>Step Description</b></td>" | out-file $html_summary -Append -Force; 
write-output "<td><b>Server/URL</b></td>" | out-file $html_summary -Append -Force; 
write-output "<td><b>Comment</b></td>" | out-file $html_summary -Append -Force; 
write-output "<td><b>Status</b></td>" | out-file $html_summary -Append -Force; 
write-output "</tr>" | out-file $html_summary -Append -Force; 



write-output "" | out-file $persona_summary;
write-output "<br>" | out-file $persona_summary -Append -Force;
write-output "<table border='2px' style='border-collapse: collapse;'>" | out-file $persona_summary -Append -Force; 
write-output "<tr bgcolor='yellow'>" | out-file $persona_summary -Append -Force; 
write-output "<td><b>Server Name</b></td>" | out-file $persona_summary -Append -Force; 
write-output "<td><b>Module Name</b></td>" | out-file $persona_summary -Append -Force; 
write-output "<td><b>Description</b></td>" | out-file $persona_summary -Append -Force; 
write-output "<td><b>Status</b></td>" | out-file $persona_summary -Append -Force; 
write-output "</tr>" | out-file $persona_summary -Append -Force; 



Try{
		
	add_row_to_html_summary_table "Validating public URL" "$public_url" " " "STARTING";
	write-output "$(get-date) : Validating public URL: $public_url " | out-file $LOG_FILE -Append -Force;  
	#Here we are validating the public URL
	write-output "Public URL validation:<br>" | out-file $html_file -Append -Force; 
	$tmp=$public_url -split "://"
	$public_url_protocol=$tmp[0]
	$public_url=$tmp[1]

	#---TRUE flag means persona validation is on
	
	if ( $persona_validation -eq "TRUE"){
		tests_byURL $public_url $public_url_protocol 'TRUE';
	} else {
		tests_byURL $public_url $public_url_protocol
	}	
	
	add_row_to_html_summary_table "Validating App URL" "$app_url" " " "STARTING";
	write-output "$(get-date) : Validating App URL: $app_url " | out-file $LOG_FILE -Append -Force;  
	#Here we are validating the app URL
	write-output "<br>App URL validation:<br>" | out-file $html_file -Append -Force; 
	$tmp=$app_url -split "://"
	$app_url_protocol=$tmp[0]
	$app_url=$tmp[1]


	tests_byURL $app_url $public_url_protocol;
	
	write-output "<br><br>Replication Test through public URL:" | out-file $html_file -Append -Force; 
	perform_replication_test $public_url $public_url_protocol;

} Catch {
    
	$email_flag='false';
	$ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
	
	add_row_to_html_summary_table "Validating  URL" "" " ErrorMessage : $ErrorMessage" "FAILED";
	write-output "#ERROR1a# ErrorMessage : $ErrorMessage" | out-file $LOG_FILE -Append -Force;
	write-output "#ERROR1a# FailedItem : $FailedItem" | out-file $LOG_FILE -Append -Force;
	
	write-output "<SPAN style='COLOR: red'>Exception Occurred</SPAN>" | out-file $html_file -Append -Force;

}

write-output "$(get-date) : URL validation over" | out-file $LOG_FILE -Append -Force;


#------------------------ 
write-output "$(get-date) : Starting the Import Configuration Test" | out-file $LOG_FILE -Append -Force;
write-output "<br><br>Import Configuration Test:<br>" | out-file $html_file -Append -Force; 
import_configuration_test $public_url $public_url_protocol;
write-output "$(get-date) : *** Import Configuration Test over ***" | out-file $LOG_FILE -Append -Force; 
#------------------------ 


#------------------------ 
write-output "$(get-date) : Queue Segment Test" | out-file $LOG_FILE -Append -Force;
write-output "<br><br>Queue Segment Test:<br>" | out-file $html_file -Append -Force; 
queue_segement_status
write-output "$(get-date) : *** Queue Segment Test over ***" | out-file $LOG_FILE -Append -Force; 
#------------------------ 


write-output "$(get-date) : Servers to validate: $all_servers" | out-file $LOG_FILE -Append -Force;  


if ( $output_into_single_file_enable -match 'TRUE'){
	
	write-output "$(get-date) : Proceeding with validation of servers one after another " | out-file $LOG_FILE -Append -Force;  
	write-output "$(get-date) : Non-Multithreaded approach " | out-file $LOG_FILE -Append -Force;  
		#Multi Threading is disabled. Output will come to a single file 
		#Script will validate one server completely and then move to next
		
		echo "--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------<br>" >> $html_report
		echo "--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------<br>" >> $html_report
		
		write-output "$(get-date) : Validating WEB servers: $web_servers_to_validate " | out-file $LOG_FILE -Append -Force;  
		foreach ($server_name in $web_servers_to_validate){
			write-output "$(get-date) : Validating $server_name " | out-file $LOG_FILE -Append -Force; 
			add_row_to_html_summary_table "Server Level validation" "$server_name" "-" "STARTING";
				Try{
					
					basic_preconfigured_tests $server_name $web_services 'TRUE'
				} Catch {
					$email_flag='false';
					$ErrorMessage = $_.Exception.Message
					$FailedItem = $_.Exception.ItemName
					write-output "#ERROR1# ErrorMessage : $ErrorMessage" | out-file $LOG_FILE -Append -Force;
					write-output "#ERROR1# FailedItem : $FailedItem" | out-file $LOG_FILE -Append -Force;
				   add_row_to_html_summary_table "Server Level validation" "$server_name" "ErrorMessage : $ErrorMessage" "FAILED";
				    write-output "<SPAN style='COLOR: red'>Exception Occurred</SPAN>" | out-file $html_file -Append -Force;
				}
			add_row_to_html_summary_table "Server Level validation" "$server_name" "-" "COMPLETED";
			write-output "$(get-date) : ********----********* " | out-file $LOG_FILE -Append -Force;  
		}
		
		echo "--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------<br>" >> $html_report
		echo "--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------<br>" >> $html_report
		
		write-output "$(get-date) : Validating App servers : $app_servers_to_validate" | out-file $LOG_FILE -Append -Force;  
		foreach ($server_name in $app_servers_to_validate){
			write-output "$(get-date) : Validating $server_name " | out-file $LOG_FILE -Append -Force;  
			add_row_to_html_summary_table "Server Level validation" "$server_name" "-" "STARTING";
				Try{
					basic_preconfigured_tests $server_name $app_services
				} Catch {
					$email_flag='false';
					$ErrorMessage = $_.Exception.Message
					$FailedItem = $_.Exception.ItemName
					write-output "#ERROR2# ErrorMessage : $ErrorMessage" | out-file $LOG_FILE -Append -Force;
					write-output "#ERROR2# FailedItem : $FailedItem" | out-file $LOG_FILE -Append -Force;
				   add_row_to_html_summary_table "Server Level validation" "$server_name" "ErrorMessage : $ErrorMessage" "FAILED";
				    write-output "<SPAN style='COLOR: red'>Exception Occurred</SPAN>" | out-file $html_file -Append -Force;
				}

			add_row_to_html_summary_table "Server Level validation" "$server_name" "-" "COMPLETED";
			write-output "$(get-date) : ********----********* " | out-file $LOG_FILE -Append -Force;  
		}
		
} else {
	
	write-output "$(get-date) : Proceeding with validation of all servers at once " | out-file $LOG_FILE -Append -Force;  
	write-output "$(get-date) : Multithreaded approach " | out-file $LOG_FILE -Append -Force;  
	
	foreach ($server_name in $all_servers){
		Invoke-Command -ScriptBlock ${function:basic_preconfigured_tests} -argumentlist $server_name
	}
}
write-output "</table>" | out-file $html_summary -Append -Force; 
write-output "</table>" | out-file $persona_summary -Append -Force; 

###############################################################################
write-output "==================================================================================" | out-file $LOG_FILE -Append -Force;  
write-output "$(get-date) : Scanning the Log file for error messages:" | out-file $LOG_FILE -Append -Force;  
Sleep $sleeptime;

$tmp=Select-String -Path $LOG_FILE -pattern "#ERROR" 
$err_length=(Select-String -Path $LOG_FILE -pattern "#ERROR").Length;
$tmp >>$LOG_FILE
if ( $err_length -gt 0){ $email_flag='false'; }

write-output "" | out-file $LOG_FILE -Append -Force;  
write-output "$(get-date) : Scanning the html file for error messages:" | out-file $LOG_FILE -Append -Force;  


$tmp=Select-String -Path $html_file -pattern "<SPAN style='COLOR: red'>" 
$err_length=(Select-String -Path $html_file -pattern "<SPAN style='COLOR: red'>").Length;
$tmp >>$LOG_FILE
if ( $err_length -gt 0){ $email_flag='false'; }
write-output "==================================================================================" | out-file $LOG_FILE -Append -Force;  
###############################################################################
Sleep $sleeptime;



if ( $email_flag -match 'TRUE'){
	write-output "$(get-date) : Preparing Success Email " | out-file $LOG_FILE -Append -Force;  
	$Subject = "$config_file || $envt_type || Health Test Report"
} else {
	write-output "$(get-date) : Preparing Failure Email " | out-file $LOG_FILE -Append -Force;  
	$Subject = "$config_file ||  $envt_type || Health Test Report"
}
write-output "$(get-date) : Validation job completed " | out-file $LOG_FILE -Append -Force;  




echo "">$html_report
write-output "<html>" | out-file $html_report -Append -Force; 
write-output "<body><br>" | out-file $html_report -Append -Force; 
write-output "Hi Team,<br>" | out-file $html_report -Append -Force; 
write-output "<br><br>" | out-file $html_report -Append -Force; 
write-output "Here is the health test & other validation report.<br>" | out-file $html_report -Append -Force; 
write-output "<b>Please go through the email and find attached logfile for more details.<b><br>" | out-file $html_report -Append -Force; 

$tmp=get-content $html_summary
echo "<br><br>" >> $html_report
echo "Health Test Summary" >> $html_report
echo "<br>" >> $html_report
echo $tmp >> $html_report
Sleep $sleeptime;


if ( $persona_validation -eq "TRUE"){

	$tmp=get-content $persona_summary
	echo "<br><br>" >> $html_report
	echo "Persona Modules Status" >> $html_report
	echo "<br>" >> $html_report
	echo $tmp >> $html_report
	Sleep $sleeptime;
}

$tmp=get-content $html_file
echo "<br><br>" >> $html_report
echo "--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------<br>" >> $html_report
echo "--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------<br>" >> $html_report
echo "<br>" >> $html_report
echo "Health Test Detailed Report<br><br><br>" >> $html_report
echo $tmp >> $html_report


$body = get-content $html_report
$attach_log = "$LOG_FILE"


Remove-Item $persona_summary -Force
Remove-Item $html_summary -Force
Remove-Item $html_file -Force
 
#################################### 

$message = new-object System.Net.Mail.MailMessage
$message.From = $mail_from
$message.To.Add($mail_to)
$message.CC.Add($mail_cc)
$message.IsBodyHtml = $True
#$attach_log = new-object Net.Mail.Attachment($attach_log)
#$message.Attachments.Add($attach_log)
$message.Subject=$Subject
$message.Subject="Azure POC || Horizontal Scaling Alert"
$message.body = $body

#$smtp = new-object Net.Mail.SmtpClient($smtpserver)
$message > test.txt

$SMTPServer = "smtp.gmail.com"
$SMTPPort = "587"
$Username = "testingpurpose2018011@gmail.com"
$Password = "Strictly_forStudents"


$smtp = New-Object System.Net.Mail.SmtpClient($SMTPServer, $SMTPPort);
$smtp.EnableSSL = $true
$smtp.Credentials = New-Object System.Net.NetworkCredential($Username, $Password);
$smtp.send($message)
write-host "Mail Sent"



##################################################################################
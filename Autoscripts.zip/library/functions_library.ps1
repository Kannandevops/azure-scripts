function Confirm-WindowsServiceExists($server_name, $service_name)
{   

   if (Get-Service -Name $service_name -ErrorAction SilentlyContinue -ErrorVariable WindowsServiceExistsError)
   {
      # Write-Host "$name Exists on $server"
	  
       return $true
   }

   if ($WindowsServiceExistsError)
   {
		write-output "$(get-date) : #ERR--#:  $service_name not found on $server_name Here is the exception message $WindowsServiceExistsError[0].exception.message " | out-file $LOG_FILE -Append -Force;  

   }

   return $false
}


function Track_Service_Status($arr_servers, $arr_services){

write-output "<table style='border:1px'>" | out-file $html_file -Append -Force; 
write-output "<tr bgcolor='yellow'>" | out-file $html_file -Append -Force; 
write-output "<td><b>Server</b></td>" | out-file $html_file -Append -Force; 
write-output "<td><b>Service</b></td>" | out-file $html_file -Append -Force; 
write-output "<td><b>Status</b></td>" | out-file $html_file -Append -Force; 
write-output "<td><b>Startup Type</b></td>" | out-file $html_file -Append -Force; 
write-output "<td><b>Service User</b></td>" | out-file $html_file -Append -Force; 
write-output "</tr>" | out-file $html_file -Append -Force; 

	foreach ($server_name in $arr_servers){
		
		foreach ($service_name in $arr_services){
		
		write-output "<tr>" | out-file $html_file -Append -Force; 	
		write-output "<td><b>$server_name</b></td>" | out-file $html_file -Append -Force; 
		write-output "<td><b>$service_name</b></td>" | out-file $html_file -Append -Force; 
			
		if(Confirm-WindowsServiceExists "$server_name" "$service_name"  ){
			$status_tmp=(Get-Service -Name $service_name).Status;
			write-output "<td><b>$status_tmp</b></td>" | out-file $html_file -Append -Force; 

            $tmp=Get-WmiObject -Query "Select StartMode,StartName From Win32_Service Where Name='$service_name'"
			$tmp_mode=$tmp.StartMode
			$tmp_user=$tmp.StartName
            write-output "<td><b>$tmp_mode</b></td>" | out-file $html_file -Append -Force; 
            write-output "<td><b>$tmp_user</b></td>" | out-file $html_file -Append -Force; 
			
			
			if ($status_tmp -match 'Running'){
				add_row_to_html_summary_table "Services Test" "$server_name" "Tracking service $service_name | Status: $status_tmp" "RUNNING";
				} else {  
				add_row_to_html_summary_table "Services Test" "$server_name" "Tracking service $service_name | Status: $status_tmp" "STOPPED";
			}


			
		} else {
				add_row_to_html_summary_table "Services Test" "$server_name" "Tracking service $service_name | Service Not Installed/Un-tracable " "MANUAL";
		
                write-output "<td><SPAN style='COLOR: OrangeRed '>Service Not Installed/Un-tracable</SPAN></td>" | out-file $html_file -Append -Force; 
				write-output "<td><SPAN style='COLOR: OrangeRed '><b>NA</b></SPAN></td>" | out-file $html_file -Append -Force; 
				write-output "<td><SPAN style='COLOR: OrangeRed '><b>NA</b></SPAN></td>" | out-file $html_file -Append -Force; 
			}	
		}
		write-output "</tr>" | out-file $html_file -Append -Force; 		
	}
	write-output "</table>" | out-file $html_file -Append -Force; 	
}



function tests_byURL($to_validate,$protocol,  $persona_test='false'){

$URI = $protocol+"://" +$to_validate +"/portal/content/getwaveversion.asp";
	$HTML = Invoke-WebRequest -Uri $URI 
	$app_version=$HTML.ParsedHtml.body.outerHTML
	$tables = @($HTML.ParsedHtml.getElementsByTagName("TABLE"))
	$table = $tables[0]
	$titles = @()
	$rows = @($table.Rows)

	$app_version=$rows[4].innerHtml -split "<TD class=category>Release</TD>" -split "<TD>" -split "</TD>"
	$app_version = "$app_version" -replace '\s',''
	
	#($HTML.ParsedHtml.getElementsByTagName('h2') | Where{ $_.className -eq 'entry-title'} ).innerText
	
write-output "<br>" | out-file $html_file -Append -Force; 

write-output "<table style='border:1px'>" | out-file $html_file -Append -Force; 
write-output "<tr bgcolor='yellow'>" | out-file $html_file -Append -Force; 
write-output "<td><b>Server/URL</b></td>" | out-file $html_file -Append -Force; 
write-output "<td><b>GetWaveVersion</b></td>" | out-file $html_file -Append -Force; 
write-output "</tr>" | out-file $html_file -Append -Force; 

		write-output "<tr>" | out-file $html_file -Append -Force; 	
			write-output "<td><b>$to_validate</b></td>" | out-file $html_file -Append -Force; 
			write-output "<td><b>$app_version</b></td>" | out-file $html_file -Append -Force; 
		write-output "</tr>" | out-file $html_file -Append -Force; 		
	
	write-output "</table>" | out-file $html_file -Append -Force; 	

#----------writing to summary
add_row_to_html_summary_table "Health Test" $to_validate "App Version found: $app_version" "SUCCESS";
	$table = $tables[2]
	$rows = @($table.Rows)
	
	write-output "<br>" | out-file $html_file -Append -Force; 
	write-output "<h3><font color='blue'>Wave tests:</font><br></h3>" | out-file $html_file -Append -Force; 

	write-output "<table style='border:1px'>" | out-file $html_file -Append -Force; 
	foreach($row in $rows){	
		write-output "<tr>" | out-file $html_file -Append -Force; 	
		write-output $row.innerHTml | out-file $html_file -Append -Force; 	
		write-output "</tr>" | out-file $html_file -Append -Force; 	
	}
	write-output "</table>" | out-file $html_file -Append -Force; 	
	
	

	
#======================================
	$URI = $protocol+"://" +$to_validate +"/portal/content/HealthTest.asp";
	#echo $URI
		Try{
			ui_health_test_url $URI;
			#----------writing to summary	
			add_row_to_html_summary_table "Health Test" $to_validate "Wave Test" "SUCCESS";
		} Catch {
		#----------writing to summary	
		add_row_to_html_summary_table "Health Test" $to_validate "Wave Test" "FAILED";
			$ErrorMessage = $_.Exception.Message
			$FailedItem = $_.Exception.ItemName
			write-output "#ERROR4# ErrorMessage : $ErrorMessage" | out-file $LOG_FILE -Append -Force;
			write-output "#ERROR4# FailedItem : $FailedItem" | out-file $LOG_FILE -Append -Force;
			
		}
#======================================	


#Persona Validation by URL

if ( $persona_test -eq "TRUE"){
if ( $persona_validation -eq "TRUE"){
$PERSONA_URL_MAIN = $protocol+"://" +$to_validate +"/retail";

write-output "#Information: Performing health test for $PERSONA_URL_MAIN" | out-file $LOG_FILE -Append -Force;

$global:ie = New-Object -com "InternetExplorer.Application"
$global:ie.Navigate("about:blank")
$global:ie.visible = $true

Try{
	NavigateTo $PERSONA_URL_MAIN
	
	$button_div=$global:ie.Document.getElementById('loginButton')
	write-output "<h3><br>  Persona URL Test: <font color='blue'>($PERSONA_URL_MAIN)</font> " | out-file $html_file -Append -Force;
	
echo $PERSONA_URL_MAIN   $button_div.outerHTML >> C:\test.txt

if ($button_div.outerHTML -like '*=*'){	
		add_row_to_html_summary_table "*Persona URL" "$PERSONA_URL_MAIN" " " "SUCCESS";	
		write-output "<SPAN style='COLOR: green'> Test Passed</SPAN><br>" | out-file $html_file -Append -Force;
		write-output "$(get-date) : *** Persona URL $PERSONA_URL_MAIN test success ***" | out-file $LOG_FILE -Append -Force; 			
	} else {
		add_row_to_html_summary_table "*Persona URL" "$PERSONA_URL_MAIN" " " "FAILED";
		write-output "<SPAN style='COLOR: red'> Failed <br></SPAN>" | out-file $html_file -Append -Force; 
		write-output "$(get-date) : *** Persona URL $PERSONA_URL_MAIN test failed ***" | out-file $LOG_FILE -Append -Force; 		
	}
	
} Catch {
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
	write-output "#ERROR_persona-# ErrorMessage : $ErrorMessage" | out-file $LOG_FILE -Append -Force;
	write-output "#ERROR_persona-# FailedItem : $FailedItem" | out-file $LOG_FILE -Append -Force;
}
sleep 2
$global:ie.quit() 
sleep 2


#----Persona Modules----*****
$PERSONA_URL_ABOUT = $protocol+"://" +$to_validate +"/retail/about";

$HTML = Invoke-WebRequest -Uri $PERSONA_URL_ABOUT
$tmp=$web_servers_to_validate[0]
[xml]$rpweb_content = Get-Content \\$tmp\e$\RedPrairieRetail\DefaultInstance\Personae\Tomcat\WEB-INF\settings\rpweb.xml

write-output "RPWEB File \\$tmp\d$\RedPrairieRetail\DefaultInstance\Personae\Tomcat\WEB-INF\settings\rpweb.xml" | out-file $LOG_FILE -Append -Force;
$modules = $rpweb_content.config.connections.rps.ChildNodes.application
#$modules=@("sitemgr","ess","dm","admin","mecmmc","retailwebapi")

	write-output "Modules to be tested : $modules  for $PERSONA_URL_ABOUT" | out-file $LOG_FILE -Append -Force;
  	write-output "<br><h3>[Validating : $PERSONA_URL_ABOUT Modules to be tested : $modules]</h3>" | out-file $html_file -Append -Force;
	
$module_count=$modules.Length
$error_count=$module_count;
$version_count=0




forEach($module_name in $modules){

echo "CAME INSIDE------"
$table_id=$module_name + '-versions'
echo "table id: $table_id"
$tmp = $table=$html.ParsedHtml.getElementsByTagName('TABLE') | Where-Object {$_.id -eq $table_id} 
$tmp = $tmp | Select-Object -Last 1
$data = $tmp.rows

    :nextRow
    forEach($datum in $data){
            $cells = $datum.children
     
            forEach($cell in $cells){
               if ($cell.innerText -eq 'ApplicationVersion'){
                
                    $module_app_version = $datum.innerText -replace "ApplicationVersion",'' 
                    

                    if($module_app_version -eq ''){
                        $module_app_version="NA"
                        echo "$module_name -->  'NA'  --> ERROR"
						write-output "<tr bgcolor='red'>  <td> $to_validate </td>   <td> $module_name </td>  <td>Unable to read the version of this module in about page</td>  <td>Error</td>  </tr>" | out-file $persona_summary -Append -Force; 


                    } else{
						$error_count--
                        $version_count++
                        echo "$module_name -->  $module_app_version  --> Good"
						write-output "<tr>  <td> $to_validate </td>   <td> $module_name </td>  <td></td>  <td>Success</td>  </tr>" | out-file $persona_summary -Append -Force; 
                       Break nextRow
                    }
                    
                }
            }
        }
		
		if ($data.length -eq 0){
				echo "$module_name -->  'NA'  --> ERROR"
				write-output "<tr bgcolor='red'>  <td> $to_validate </td>   <td> $module_name </td>  <td>Module not found</td>  <td>Error</td>  </tr>" | out-file $persona_summary -Append -Force; 
      
		}
}
echo "Errors detected: "$error_count
echo "Versions detected: "$version_count
echo "Versions expected: " $modules.Length

if ($error_count -eq 0){

	if ( $version_count -eq $modules.Length){
		
		write-output "<h3><br>Persona Modules Test: <font color='blue'>Success</font> <br>" | out-file $html_file -Append -Force;
		add_row_to_html_summary_table "*Persona modules Test" $PERSONA_URL_ABOUT " " "SUCCESS";
		write-output "$(get-date) : all persona Modules are active " | out-file $LOG_FILE -Append -Force;  
		
		write-output "<tr bgcolor='#5EFF33'>  <td> $to_validate </td>   <td>  </td>  <td>INFO: Errors encountered:$error_count | Module Versions detected: $version_count | Versions expected $module_count</td>  <td>SUCCCESS</td>  </tr>" | out-file $persona_summary -Append -Force; 

		
	} else {	
		write-output "<h3><br>Persona Modules Test: <font color='red'>Failed($error_count Modules are in error state)</font> <br>" | out-file $html_file -Append -Force;
		add_row_to_html_summary_table "*Persona modules Test" $PERSONA_URL_ABOUT " " "FAILED";
		write-output "$(get-date) : $error_count Modules are in error state. $version_count modules were found good " | out-file $LOG_FILE -Append -Force;  
	
		write-output "<tr bgcolor='red'>  <td> $to_validate </td>   <td>  </td>  <td>INFO: Errors encountered:$error_count | Module Versions detected: $version_count | Versions expected $module_count </td>  <td>FAILURE-not all modules are active</td>  </tr>" | out-file $persona_summary -Append -Force; 

		
	}
} else {
		write-output "<h3><br>Persona Modules Test: <font color='red'>Failed($error_count Modules are in error state)</font> <br>" | out-file $html_file -Append -Force;
		add_row_to_html_summary_table "*Persona modules Test" $PERSONA_URL_ABOUT " " "FAILED";
		write-output "$(get-date) : $error_count Modules are in error state. $version_count modules were found good " | out-file $LOG_FILE -Append -Force;  
		
		write-output "<tr bgcolor='red'>  <td> $to_validate </td>   <td>  </td>  <td>INFO: Errors encountered:$error_count | Module Versions detected: $version_count | Versions expected $module_count </td>  <td>FAILURE- Encountered $error_count error</td>  </tr>" | out-file $persona_summary -Append -Force; 

}

	#----End of Persona Modules test
	}
#end of Persona validation by URL

}
}



#==========================================================================================
#Import configuration Test
function import_configuration_test($to_validate,$protocol){

#Preparing the export path
try{

$url = $protocol+"://" +$to_validate +"/portal/content/getwaveversion.asp";

	$HTML = Invoke-WebRequest -Uri $url
	$tables = @($HTML.ParsedHtml.getElementsByTagName("TABLE"))
	$table = $tables[0]
	$rows = @($table.Rows)

	$tmp=$rows.innerHtml
	$tmp=$tmp -replace '\s',''
	$namespace=$tmp | Select-String -Pattern "Namespace"
	$namespace_string=$namespace[0].toString()
	$namespace =$namespace_string -split "</TD><TD>" 
	$namespace =$namespace[1]
	$namespace =$namespace -split "</TD>"
	$namespace=$namespace[0]
	
	#searching for import/export path now
	$table = $tables[1]
	$rows = @($table.Rows)
	
	$tmp=$rows.innerHtml
	$tmp=$tmp -replace '\s',''
	$t=$tmp | Select-String -Pattern "__ImportExportDirectory"
	$t=$t[0].toString()
	$t =$t -split "</TD><TD>" 
	$t =$t[1]
	$t =$t -split "</TD>"
	$IE_directory=$t[0]
	
	#echo "IMPORT CONFIGURATION PATH: $IE_directory\imports\$namespace\0\importconfigurationtest\"
	$import_export_test_path="$IE_directory\imports\$namespace\0\importconfigurationtest\"
	write-output "$(get-date) : import_export_test_path :- $import_export_test_path" | out-file $LOG_FILE -Append -Force; 
	add_row_to_html_summary_table "Import Configuration Test" $import_export_test_path "Import Path Identification" "SUCCESS";
}catch{
	$ErrorMessage = $_.Exception.Message
	$FailedItem = $_.Exception.ItemName

	write-output "ERROR# Import_config_test ErrorMessage : $ErrorMessage" | out-file $LOG_FILE -Append -Force;
	write-output "ERROR# Import_config_test FailedItem : $FailedItem" | out-file $LOG_FILE -Append -Force;
	add_row_to_html_summary_table "Import Configuration Test" $import_export_test_path "Import Path Identification" "FAILED";
}

#Placing the falg files at the import_export directory
try{
copy library\test.test $import_export_test_path\test.test
sleep 2
echo "" >$import_export_test_path\test.test.flag
sleep 2
rename-item -path $import_export_test_path\test.test.flag -newname $import_export_test_path\test.test.done


}catch{
add_row_to_html_summary_table "Import Configuration Test" $import_export_test_path "Failed to write files" "FAILED";

	write-output "ERROR# Unable to place the files for import test" | out-file $LOG_FILE -Append -Force;
	write-output "ERROR# Import_config_test ErrorMessage : $ErrorMessage" | out-file $LOG_FILE -Append -Force;
	write-output "ERROR# Import_config_test FailedItem : $FailedItem" | out-file $LOG_FILE -Append -Force;
}
sleep 15
try{
$datatable_source_details = New-Object System.Data.DataTable
$connectionString="Data Source=$db_server;Initial Catalog=$db_name;uid=$db_user;pwd=$db_pass"					
$connection = New-Object -TypeName System.Data.SqlClient.SqlConnection($connectionString)
$query="use $db_name; select count(1) from ape_execution_queue where execution_moniker ='Platform.Import.ImportConfigurationTestTask' and execution_queued_timestamp > GETDATE() - 0.004"
write-output "Executing query: $query" | out-file $LOG_FILE -Append -Force;

$command = New-Object -TypeName System.Data.SqlClient.SqlCommand($query, $connection)
$connection.Open()

$Reader = $command.ExecuteReader()
$datatable_source_details.Load($Reader)
$count=$datatable_source_details.Column1
$connection.Close()

} catch {
add_row_to_html_summary_table "Import Configuration Test" "$db_server // $db_name" "Unable to execute query on database" "FAILED";

	write-output "ERROR# Unable to execute query on database" | out-file $LOG_FILE -Append -Force;
	write-output "ERROR# Import_config_test ErrorMessage : $ErrorMessage" | out-file $LOG_FILE -Append -Force;
	write-output "ERROR# Import_config_test FailedItem : $FailedItem" | out-file $LOG_FILE -Append -Force;
}
if ($count -ge 1){
add_row_to_html_summary_table "Import Configuration Test" "$db_server // $db_name" " " "SUCCESS";

	write-output "Import Test passed" | out-file $LOG_FILE -Append -Force;
	write-output "<br><SPAN style='COLOR: green'>Test Passed</SPAN><br>" | out-file $html_file -Append -Force; 
} else {
add_row_to_html_summary_table "Import Configuration Test" "$db_server // $db_name" "import job not processing" "FAILED";
  	write-output "<br><SPAN style='COLOR: red'>Import Configuration test failed. Please check on this</SPAN><br>" | out-file $html_file -Append -Force;
	write-output "ERROR# Import Configuration test failed. Please check on this" | out-file $LOG_FILE -Append -Force;

	}
}
#==========================================================================================




function queue_segement_status(){

$disabled_queue_segements = New-Object System.Data.DataTable

try{
$datatable_source_details = New-Object System.Data.DataTable
$connectionString="Data Source=$db_server;Initial Catalog=$db_name;uid=$db_user;pwd=$db_pass"	
$connection = New-Object -TypeName System.Data.SqlClient.SqlConnection($connectionString)
$query="use $db_name; select segment_name,active_flag  from APE_Execution_Queue_Segment where active_flag ='N'"
#$query="use gpa_test; select segment_name,active_flag  from APE_Execution_Queue_Segment"
write-output "Executing query: $query" | out-file $LOG_FILE -Append -Force;

$command = New-Object -TypeName System.Data.SqlClient.SqlCommand($query, $connection)
$connection.Open()

$Reader = $command.ExecuteReader()
$disabled_queue_segements.Load($Reader)
$count=$disabled_queue_segements.Rows.Count
$connection.close()

} catch {
add_row_to_html_summary_table "Queue Segement Test" "$db_server // $db_name" "Uanble to execute query on DB" "FAILED";
	write-output "ERROR# Unable to execute query on database" | out-file $LOG_FILE -Append -Force;
	write-output "ERROR# Queue_Segement_Test ErrorMessage : $ErrorMessage" | out-file $LOG_FILE -Append -Force;
	write-output "ERROR# Queue_Segement_Test FailedItem : $FailedItem" | out-file $LOG_FILE -Append -Force;
}


if ($count -ge 1){
	write-output "ERROR# Queue Segement Test failed. Please check on this" | out-file $LOG_FILE -Append -Force;

write-output "<br><SPAN style='COLOR: red'> Queue Segement Test failed. Below Segements are disabled. Please check on this on priority:<br></SPAN>" | out-file $html_file -Append -Force; 
write-output "<table style='border:1px'>" | out-file $html_file -Append -Force; 
write-output "<tr bgcolor='yellow'>" | out-file $html_file -Append -Force; 
write-output "<td><b>Segment Name</b></td>" | out-file $html_file -Append -Force; 
write-output "<td><b>Active Flag</b></td>" | out-file $html_file -Append -Force; 
write-output "</tr>" | out-file $html_file -Append -Force; 

	foreach( $row in $disabled_queue_segements){
        $segment_name=$row.segment_name 
        $active_flag=$row.active_flag
		write-output "<tr>" | out-file $html_file -Append -Force; 
		write-output "<td> $segment_name </td>" | out-file $html_file -Append -Force; 
		write-output "<td> $active_flag </td>" | out-file $html_file -Append -Force; 
		write-output "</tr>" | out-file $html_file -Append -Force; 
	}
write-output "</table>" | out-file $html_file -Append -Force; 
write-output "<br><br>" | out-file $html_file -Append -Force; 	
	
	add_row_to_html_summary_table "Queue Segement Test" "$db_server // $db_name" "$count queue segment disabled" "FAILED";
} else {
	add_row_to_html_summary_table "Queue Segement Test" "$db_server // $db_name" "No queue segment disabled" "SUCCESS";
  	write-output "<br><SPAN style='COLOR: green'> Test Passed</SPAN><br>" | out-file $html_file -Append -Force;
}
}



function perform_replication_test($to_validate,$protocol){
#===========================================================
	
	$URI = $protocol+"://" +$to_validate +"/portal/content/ReplicationTest.asp";
	$HTML = Invoke-WebRequest -Uri $URI
	$app_version=$HTML.ParsedHtml.body.outerHTML
	$tables = @($HTML.ParsedHtml.getElementsByTagName("TABLE"))
	$table = $tables[0]
	$titles = @()
	$rows = @($table.Rows)
	$replication_test=$rows.innerhtml -split "<TD>" -split "</TD>" -split "<B>" -split "</TD>" -split "<BR>"
	write-output "<h3><br><font color='blue'>Replication Test:<br> </font> $replication_test <br>" | out-file $html_file -Append -Force;
	
	if($replication_test -like '*success*' ){
		add_row_to_html_summary_table "Replication Test" "$to_validate" "-" "SUCCESS";
		write-output "Replication test successful for $to_validate" | out-file $LOG_FILE -Append -Force;
	} else{
	
		add_row_to_html_summary_table "Replication Test" "$to_validate" "Failure should be conditionally ignorable" "FAILED";
		write-output "#ERROR# ErrorMessage : Replication test failed for $to_validate" | out-file $LOG_FILE -Append -Force;
	}
	
#======================================
}

#-------------------------------------
function basic_preconfigured_tests($server_name, $services_arr, $persona_flag='false'){

if ( !($output_into_single_file_enable -match 'TRUE')){
	$html_file=$BASE_DIR  +"\OUTPUT\" +$server_name +"health_test.html"
}

echo "--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------<br>" >> $html_report
write-output "<h3><font color='brown'> Server name:- $server_name </font><br></h3>" | out-file $html_file -Append -Force; 


write-output "$(get-date) : Connection test for $server_name " | out-file $LOG_FILE -Append -Force;  


write-output "<table style='border:1px'>" | out-file $html_file -Append -Force; 
write-output "<tr bgcolor='yellow'>" | out-file $html_file -Append -Force; 
write-output "<td><b>Server name</b></td>" | out-file $html_file -Append -Force; 
write-output "<td><b>Connection Status</b></td>" | out-file $html_file -Append -Force; 
write-output "</tr>" | out-file $html_file -Append -Force; 
		

		
write-output "<tr>" | out-file $html_file -Append -Force; 
write-output "<td><b>$server_name</b></td>" | out-file $html_file -Append -Force; 
  if ($true){
		write-output "<td><b><font color='green'>Success</font></b></td>" | out-file $html_file -Append -Force;
		add_row_to_html_summary_table "Connection Test" "$server_name" "Server is responding to ping" "SUCCESS";
  }
  else{
		add_row_to_html_summary_table "Connection Test" "$server_name" "Server is not responding to ping" "FAILED";
		write-output "<td><SPAN style='COLOR: red'>Failed</SPAN></td>" | out-file $html_file -Append -Force;
 }
write-output "</tr>" | out-file $html_file -Append -Force; 
write-output "</table>" | out-file $html_file -Append -Force; 
		
		
write-output "<h4><br><br>Service Status:- <br></h4>" | out-file $html_file -Append -Force; 
		
write-output "$(get-date) : Tracking the service status for  $server_name " | out-file $LOG_FILE -Append -Force;  
Track_Service_Status $server_name $services_arr;	

write-output "$(get-date) : Running the health test for   $server_name " | out-file $LOG_FILE -Append -Force;  			
				Try{
					tests_byURL $server_name $server_protocol $persona_flag
				} Catch {
					$ErrorMessage = $_.Exception.Message
					$FailedItem = $_.Exception.ItemName
					add_row_to_html_summary_table "Test from URL" "$server_name" "ErrorMessage : $ErrorMessage" "STARTING";
					write-output "#ERROR3# ErrorMessage : $ErrorMessage" | out-file $LOG_FILE -Append -Force;
					write-output "#ERROR3# FailedItem : $FailedItem" | out-file $LOG_FILE -Append -Force;
				}
				
}


#--------UI Related Functions
Function WaitForPage([int] $delayTime = 10)
{
  $loaded = $false
  
  while ($loaded -eq $false) {
    [System.Threading.Thread]::Sleep($delayTime) 
    
    #If the browser is not busy, the page is loaded
    if (-not $global:ie.Busy)
    {
      $loaded = $true
    }
  }
  
  $global:doc = $global:ie.Document
  
}


Function NavigateTo([string] $url, [int] $delayTime = 100)
{
  $global:ie.Navigate($url)
  
  WaitForPage $delayTime
}

Function SetElementValueByName($name, $value, [int] $position = 0) {
  if ($global:doc -eq $null) {
    write-output "#ERROR5a# : Document is null" | out-file $LOG_FILE -Append -Force;
	
  }
  $elements = @($global:doc.getElementsByName($name))
  if ($elements.Count -ne 0) {
    $elements[$position].Value = $value
  }
  else {
    write-output "#ERROR5b# : Couldn't find any element with name ""$name""" | out-file $LOG_FILE -Append -Force;
  }
}


Function ClickElementByTagName($tagName, [int] $position = 0)
{
  if ($global:doc -eq $null) {
    write-output "#ERROR5c# : Document is null" | out-file $LOG_FILE -Append -Force;
   }
  $elements = @($global:doc.getElementsByTagName($tagName))
  if ($elements.Count -ne 0) {
    $elements[$position].Click()
    WaitForPage
  }
  else {
    write-output "#ERROR5d# : Couldn't find element ""$tagName"" at position ""$position""" | out-file $LOG_FILE -Append -Force;
  }
}

Function ClickElementById($id)
{
  $element = $global:doc.getElementById($id)
  if ($element -ne $null) {
    $element.Click()
    WaitForPage
  }
  else {
    write-output "#ERROR5e# :Couldn't find element with id ""$id""" | out-file $LOG_FILE -Append -Force;
  
  }
}

Function ClickElementByName($name, [int] $position = 0)
{
  if ($global:doc -eq $null) {
     write-output "#ERROR5f# :Document is null" | out-file $LOG_FILE -Append -Force;
  
    
  }
  $elements = @($global:doc.getElementsByName($name))
  if ($elements.Count -ne 0) {
    $elements[$position].Click()
    WaitForPage
  }
  else {
     write-output "#ERROR5f# : Couldn't find element with name ""$name"" at position ""$position""" | out-file $LOG_FILE -Append -Force;
  
  }
}


function ui_health_test_url($URI){

write-output "#Information: Performing health test for $URI" | out-file $LOG_FILE -Append -Force;
$global:ie = New-Object -com "InternetExplorer.Application"
$global:ie.Navigate("about:blank")
#$global:ie.visible = $true


Try{
	NavigateTo $URI
	SetElementValueByName "userName" $user_name
	SetElementValueByName "password" $user_password
	SetElementValueByName "emailAddress" $test_email
	ClickElementByName "loginButton"
	
} Catch {
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
	write-output "#ERROR5-# ErrorMessage : $ErrorMessage" | out-file $LOG_FILE -Append -Force;
	write-output "#ERROR5-# FailedItem : $FailedItem" | out-file $LOG_FILE -Append -Force;
}
	
	$global:ie.Document.body.outerHTML >> $html_file
	Sleep 5
$global:ie.quit() 
}
#-------end of ui related functions------


#------------------------------------

function add_row_to_html_summary_table($var_step_desc,$var_server_url,$var_comment,$var_status){
$global:step_number = $step_number  +1;
$step_desc=$var_step_desc
$server_url=$var_server_url
$comment=$var_comment
$status=$var_status


if ($status -match 'FAILED'){
write-output "<tr bgcolor='#ff6666'>" | out-file $html_summary -Append -Force;
} elseif ($status -match 'RUNNING'){
write-output "<tr bgcolor='#5EFF33'>" | out-file $html_summary -Append -Force;
}elseif ($status -match 'STOPPED'){
write-output "<tr bgcolor='OrangeRed'>" | out-file $html_summary -Append -Force;
} else{
write-output "<tr bgcolor='#ccffeb'>" | out-file $html_summary -Append -Force;
} 

	write-output "<td>$step_number</td>" | out-file $html_summary -Append -Force;
	write-output "<td>$step_desc</td>" | out-file $html_summary -Append -Force;
	write-output "<td>$server_url</td>" | out-file $html_summary -Append -Force;
	write-output "<td>$comment</td>" | out-file $html_summary -Append -Force;
	write-output "<td>$status</td>" | out-file $html_summary -Append -Force;
write-output "</tr>" | out-file $html_summary -Append -Force;

}

#----------------------------------END OF FILE--------------------------------------------
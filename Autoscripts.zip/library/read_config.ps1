
$content = Get-Content $global_values

foreach ($line in $content){

if ( $line -match 'OUTPUT_INTO_SINGLE_FILE_ENABLE'){
		
		$output_into_single_file_enable = $line -replace "OUTPUT_INTO_SINGLE_FILE_ENABLE:-",'' 
		
	}
	if ( $line -match 'VALIDATE_SERVICES'){
		
		$validate_services = $line -replace "VALIDATE_SERVICES:-",'' 
		
	}
	
	
	if ( $line -match 'HEALTH_TEST'){
		
		$health_test = $line -replace "HEALTH_TEST:-",'' 
		
	}
	if ( $line -match 'TEST_EMAIL'){
		
		$test_email = $line -replace "TEST_EMAIL:-",'' 
		
	}
	
	
	#Preparing mail variables
	if ( $line -match 'MAIL_FROM'){
		
		$mail_from= $line -replace "MAIL_FROM:-",'' 
		
	}

	#Preparing mail variables
	if ( $line -match 'MAIL_TO'){
		
		$mail_to= $line -replace "MAIL_TO:-",'' 
		
	}

	#Preparing mail variables
	if ( $line -match 'MAIL_CC'){
		
		$mail_cc= $line -replace "MAIL_CC:-",'' 
		
	}

	#Preparing mail variables
	if ( $line -match 'SMTPSERVER'){
		
		$smtpserver= $line -replace "SMTPSERVER:-",'' 
		
	}
	
	#Preparing mail variables
	if ( $line -match 'ENVT_TYPE'){
		
		$envt_type= $line -replace "ENVT_TYPE:-",'' 
		
	}
	
	
}

$content = Get-Content $envt_details

foreach ($line in $content)
{
	#If the line is containing server's list, assign its values to $server_list variable
	if ( $line -match 'APP_SERVERS_TO_VALIDATE:-'){
		
		$app_servers_to_validate = $line -replace "APP_SERVERS_TO_VALIDATE:-",'' 
		
	}
	
	#If the line is containing server's list, assign its values to $server_list variable
	if ( $line -match 'APP_SERVICES'){
		
		$app_services = $line -replace "APP_SERVICES:-",'' 
		
	}
	
	#If the line is containing server's list, assign its values to $server_list variable
	if ( $line -match 'WEB_SERVERS_TO_VALIDATE'){
		
		$web_servers_to_validate = $line -replace "WEB_SERVERS_TO_VALIDATE:-",'' 
		
	}
	
	#If the line is containing service's list, assign its values to $service_list variable
	if ( $line -match 'WEB_SERVICES'){
		
		$web_services = $line -replace "WEB_SERVICES:-",'' 
		
	}
	
	if ( $line -match 'SERVER_PROTOCOL'){
		
		$server_protocol = $line -replace "SERVER_PROTOCOL:-",'' 
		
	}
	
	if ( $line -match 'PUBLIC_URL'){
		
		$public_url = $line -replace "PUBLIC_URL:-",'' 
		
	}
	
	
	if ( $line -match 'APP_URL'){
		
		$app_url = $line -replace "APP_URL:-",'' 
		
	}
	
	if ( $line -match 'OUTPUT_INTO_SINGLE_FILE_ENABLE'){
		
		$output_into_single_file_enable = $line -replace "OUTPUT_INTO_SINGLE_FILE_ENABLE:-",'' 
		
	}
	
	
	if ( $line -match 'VALIDATE_SERVICES'){
		
		$validate_services = $line -replace "VALIDATE_SERVICES:-",'' 
		
	}
	
	
	if ( $line -match 'HEALTH_TEST'){
		
		$health_test = $line -replace "HEALTH_TEST:-",'' 
		
	}
	
	
	if ( $line -match 'USER_NAME'){
		
		$user_name = $line -replace "USER_NAME:-",'' 
		
	}
	
	
	if ( $line -match 'USER_PASSWORD'){
		
		$user_password = $line -replace "USER_PASSWORD:-",'' 
		
	}
	
	
	if ( $line -match 'TEST_EMAIL'){
		
		$test_email = $line -replace "TEST_EMAIL:-",'' 
		
	}
	
	
	#Preparing mail variables
	if ( $line -match 'MAIL_FROM'){
		
		$mail_from= $line -replace "MAIL_FROM:-",'' 
		
	}

	#Preparing mail variables
	if ( $line -match 'MAIL_TO'){
		
		$mail_to= $line -replace "MAIL_TO:-",'' 
		
	}

	#Preparing mail variables
	if ( $line -match 'MAIL_CC'){
		
		$mail_cc= $line -replace "MAIL_CC:-",'' 
		
	}

	#Preparing mail variables
	if ( $line -match 'SUCCESS_MAIL_SUBJECT'){
		
		$success_mail_subject= $line -replace "SUCCESS_MAIL_SUBJECT:-",'' 
		
	}

	#Preparing mail variables
	if ( $line -match 'FAILURE_MAIL_SUBJECT'){
		
		$failure_mail_subject= $line -replace "FAILURE_MAIL_SUBJECT:-",'' 
		
	}

	#Preparing mail variables
	if ( $line -match 'SMTPSERVER'){
		
		$smtpserver= $line -replace "SMTPSERVER:-",'' 
		
	}
	
	#Preparing mail variables
	if ( $line -match 'ENVT_TYPE'){
		
		$envt_type= $line -replace "ENVT_TYPE:-",'' 
		
	}
	
	if ( $line -match 'DB_SERVER'){
		
		$db_server= $line -replace "DB_SERVER:-",'' 
		
	}
	
	if ( $line -match 'DB_NAME'){
		
		$db_name= $line -replace "DB_NAME:-",'' 
		
	}
	
	if ( $line -match 'DB_USER'){
		
		$db_user= $line -replace "DB_USER:-",'' 
		
	}
	
	if ( $line -match 'DB_PASS'){
		
		$db_pass= $line -replace "DB_PASS:-",'' 
		
	}
	
	if ( $line -match 'PERSONA_VALIDATION'){
		
		$persona_validation= $line -replace "PERSONA_VALIDATION:-",'' 
		
	}
}

write-output "$(get-date) : Reading the configuration file: " | out-file $LOG_FILE -Append -Force;  
write-output "APP_SERVERS_TO_VALIDATE :$app_servers_to_validate " | out-file $LOG_FILE -Append -Force;  
write-output "APP_SERVICES :$app_services " | out-file $LOG_FILE -Append -Force;  
write-output "WEB_SERVERS_TO_VALIDATE :$web_servers_to_validate " | out-file $LOG_FILE -Append -Force;  
write-output "WEB_SERVICES :$web_services " | out-file $LOG_FILE -Append -Force;  
write-output "PUBLIC_URL :$public_url " | out-file $LOG_FILE -Append -Force;  
write-output "APP_URL :$app_url " | out-file $LOG_FILE -Append -Force;  
write-output "SERVER_PROTOCOL :$server_protocol " | out-file $LOG_FILE -Append -Force;  

write-output "DB_SERVER :$db_server " | out-file $LOG_FILE -Append -Force;  
write-output "DB_NAME :$db_name " | out-file $LOG_FILE -Append -Force;
write-output "DB_USER :$db_user " | out-file $LOG_FILE -Append -Force;    
write-output "DB_PASS :$db_pass " | out-file $LOG_FILE -Append -Force;  

write-output "OUTPUT_INTO_SINGLE_FILE_ENABLE :$output_into_single_file_enable " | out-file $LOG_FILE -Append -Force;  
write-output "VALIDATE_SERVICES :$validate_services " | out-file $LOG_FILE -Append -Force;  
write-output "HEALTH_TEST :$health_test " | out-file $LOG_FILE -Append -Force;  
write-output "USER_NAME :$user_name " | out-file $LOG_FILE -Append -Force;   
write-output "TEST_EMAIL :$test_email " | out-file $LOG_FILE -Append -Force;
write-output "Email Settings: " | out-file $LOG_FILE -Append -Force;
write-output "MAIL_FROM :$mail_from " | out-file $LOG_FILE -Append -Force;  
write-output "MAIL_TO :$MAIL_TO " | out-file $LOG_FILE -Append -Force;  
write-output "MAIL_CC :$MAIL_CC " | out-file $LOG_FILE -Append -Force;  
write-output "SUCCESS_MAIL_SUBJECT :$success_mail_subject " | out-file $LOG_FILE -Append -Force;  
write-output "FAILURE_MAIL_SUBJECT :$failure_mail_subject " | out-file $LOG_FILE -Append -Force;  
write-output "SMTPSERVER :$smtpserver " | out-file $LOG_FILE -Append -Force;  
write-output "ENVT_TYPE :$envt_type " | out-file $LOG_FILE -Append -Force;  
write-output "PERSONA_VALIDATION :$persona_validation " | out-file $LOG_FILE -Append -Force;  

write-output "$(get-date) : Configuration read completed " | out-file $LOG_FILE -Append -Force;  
